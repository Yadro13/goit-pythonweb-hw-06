from sqlalchemy import func, desc, select
from sqlalchemy.orm import aliased
from db import session_scope
from models import Student, Group, Teacher, Subject, Grade

# 1. Top-5 students by average grade across all subjects
def select_1():
    with session_scope() as s:
        q = (
            s.query(Student.id, Student.name, func.round(func.avg(Grade.grade), 2).label("avg_grade"))
            .join(Grade, Grade.student_id == Student.id)
            .group_by(Student.id)
            .order_by(desc("avg_grade"))
            .limit(5)
        )
        return q.all()

# 2. Student with highest average grade in a specific subject (by subject_id)
def select_2(subject_id: int):
    with session_scope() as s:
        q = (
            s.query(Student.id, Student.name, func.round(func.avg(Grade.grade), 2).label("avg_grade"))
            .join(Grade, Grade.student_id == Student.id)
            .filter(Grade.subject_id == subject_id)
            .group_by(Student.id)
            .order_by(desc("avg_grade"))
            .limit(1)
        )
        return q.first()

# 3. Average grade per group for a specific subject
def select_3(subject_id: int):
    with session_scope() as s:
        q = (
            s.query(Group.id, Group.name, func.round(func.avg(Grade.grade), 2).label("avg_grade"))
            .join(Student, Student.group_id == Group.id)
            .join(Grade, Grade.student_id == Student.id)
            .filter(Grade.subject_id == subject_id)
            .group_by(Group.id)
            .order_by(Group.id)
        )
        return q.all()

# 4. Overall average grade across the whole Grade table
def select_4():
    with session_scope() as s:
        (avg_val,) = s.query(func.round(func.avg(Grade.grade), 2)).one()
        return avg_val

# 5. Courses taught by a specific teacher
def select_5(teacher_id: int):
    with session_scope() as s:
        q = s.query(Subject.id, Subject.name).filter(Subject.teacher_id == teacher_id)
        return q.all()

# 6. Students in a specific group
def select_6(group_id: int):
    with session_scope() as s:
        q = s.query(Student.id, Student.name).filter(Student.group_id == group_id).order_by(Student.id)
        return q.all()

# 7. Grades of students in a specific group for a specific subject
def select_7(group_id: int, subject_id: int):
    with session_scope() as s:
        q = (
            s.query(Student.id, Student.name, Grade.grade, Grade.graded_at)
            .join(Grade, Grade.student_id == Student.id)
            .filter(Student.group_id == group_id, Grade.subject_id == subject_id)
            .order_by(Student.id, Grade.graded_at.desc())
        )
        return q.all()

# 8. Average grade that a specific teacher gives across his subjects
def select_8(teacher_id: int):
    with session_scope() as s:
        q = (
            s.query(func.round(func.avg(Grade.grade), 2))
            .join(Subject, Subject.id == Grade.subject_id)
            .filter(Subject.teacher_id == teacher_id)
        )
        (avg_val,) = q.one()
        return avg_val

# 9. List of courses a specific student attends (has grades for)
def select_9(student_id: int):
    with session_scope() as s:
        q = (
            s.query(Subject.id, Subject.name)
            .join(Grade, Grade.subject_id == Subject.id)
            .filter(Grade.student_id == student_id)
            .group_by(Subject.id)
            .order_by(Subject.id)
        )
        return q.all()

# 10. Courses taught to a specific student by a specific teacher
def select_10(student_id: int, teacher_id: int):
    with session_scope() as s:
        q = (
            s.query(Subject.id, Subject.name)
            .join(Grade, Grade.subject_id == Subject.id)
            .filter(Grade.student_id == student_id, Subject.teacher_id == teacher_id)
            .group_by(Subject.id)
        )
        return q.all()

# Extra 1. Average grade that a specific teacher gives to a specific student
def extra_1(teacher_id: int, student_id: int):
    with session_scope() as s:
        (avg_val,) = (
            s.query(func.round(func.avg(Grade.grade), 2))
            .join(Subject, Subject.id == Grade.subject_id)
            .filter(Subject.teacher_id == teacher_id, Grade.student_id == student_id)
        ).one()
        return avg_val

# Extra 2. Grades in a group for a subject at the last lesson (latest graded_at per student)
def extra_2(group_id: int, subject_id: int):
    with session_scope() as s:
        # latest grade per student for the subject
        subq = (
            s.query(Grade.student_id, func.max(Grade.graded_at).label("max_time"))
            .join(Student, Student.id == Grade.student_id)
            .filter(Student.group_id == group_id, Grade.subject_id == subject_id)
            .group_by(Grade.student_id)
        ).subquery()

        q = (
            s.query(Student.id, Student.name, Grade.grade, Grade.graded_at)
            .join(subq, (subq.c.student_id == Student.id))
            .join(Grade, (Grade.student_id == subq.c.student_id) & (Grade.graded_at == subq.c.max_time) & (Grade.subject_id == subject_id))
            .order_by(Student.id)
        )
        return q.all()

if __name__ == "__main__":
    # Демонстраційний запуск усіх запитів
    print("1.", select_1())
    # For others you may pass IDs printed above or inspect DB first.
